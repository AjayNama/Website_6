function loginValidation(){
    var uname=document.myform.username.value;

    var pass=document.myform.password.value;

    var name=document.myform.name.value;

    var passs=document.myform.passwordd.value;



    if(uname == null || uname==""){
        alert("User Name cant be blank");
        return false;
    }else if(name == null || name==""){
        alert("Name cant be blank");
        return false;
    }else if(pass.length<6){
        alert("Password must be 6 character Long");
        return false;
    }else if(pass!=passs){
        alert("Password doesnot match");
        return false;
    }
    
}